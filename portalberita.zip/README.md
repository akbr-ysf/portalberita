# Portal Berita
Repository ini dibuat untuk keperluan sebagai ujian pembuatan projek supaya diterima magang.
